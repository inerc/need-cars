<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c0c23fb0d01f4b92a0df97b43ba6873c',
      'native_key' => 'sanitizeupload',
      'filename' => 'modNamespace/947ff55ff2172fb41f2a59e0f48bcbde.vehicle',
      'namespace' => 'sanitizeupload',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '84c8ee1039a683927551af7ddf20ce70',
      'native_key' => 5,
      'filename' => 'modPlugin/9a223eb16a9eb8a0e14fac3fbecacd62.vehicle',
      'namespace' => 'sanitizeupload',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f21781bc20cc8ea67a802908f2ddc5e0',
      'native_key' => 1,
      'filename' => 'modCategory/89d0745e4462ad878995a31973b3cea0.vehicle',
      'namespace' => 'sanitizeupload',
    ),
  ),
);