<?php
/**
 *
 * @param $data A JSON array of data to update from.
 *
 * @package group_edit
 * @subpackage processors.resource
 */
if (!$modx->hasPermission('save_document')) return $modx->error->failure($modx->lexicon('permission_denied'));
$modx->lexicon->load('resource');

$_DATA = $modx->fromJSON($scriptProperties['data']);

/* get resource */
if (empty($_DATA['id'])) return $modx->error->failure($modx->lexicon('resource_err_ns'));
$resource = $modx->getObject('modResource',$_DATA['id']);
if (empty($resource)) return $modx->error->failure($modx->lexicon('resource_err_nfs',array('id' => $_DATA['id'])));

/* check policy on resource */
if (!$resource->checkPolicy('save')) {
    return $modx->error->failure($modx->lexicon('permission_denied'));
}

/* check for locks */
$locked = $resource->addLock();
if ($locked !== true) {
    $user = $modx->getObject('modUser', $locked);
    if ($user) {
        return $modx->error->failure($modx->lexicon('resource_locked_by', array('id' => $resource->get('id'), 'user' => $user->get('username'))));
    }
}


///* set publishedon date if publish change is different */
//if (isset($_DATA['published']) && $_DATA['published'] != $resource->get('published')) {
//    if (empty($_DATA['published'])) { /* if unpublishing */
//        $_DATA['publishedon'] = 0;
//        $_DATA['publishedby'] = 0;
//    } else { /* if publishing */
//        $_DATA['publishedon'] = !empty($_DATA['publishedon']) ? strtotime($_DATA['publishedon']) : time();
//        $_DATA['publishedby'] = $modx->user->get('id');
//    }
//} else { /* if no change, unset publishedon/publishedby */
//    if (empty($_DATA['published'])) { /* allow changing of publishedon date if resource is published */
//        unset($_DATA['publishedon']);
//    }
//    unset($_DATA['publishedby']);
//}
/* Keep original publish state, if change is not permitted */
if (!$modx->hasPermission('publish_document')) {
    $_DATA['publishedon'] = $resource->get('publishedon');
    $_DATA['publishedby'] = $resource->get('publishedby');
    $_DATA['pub_date'] = $resource->get('pub_date');
    $_DATA['unpub_date'] = $resource->get('unpub_date');
    $_DATA['published'] = $resource->get('published');
}

/* save TVs */
$tvs = $resource->getTemplateVars();
foreach ($tvs as $tv) {
    $tv_id = $tv->get('id');
    if(isset($_DATA['tv'.$tv_id])){
        $value = $_DATA['tv'.$tv_id];
        $default = $tv->processBindings($tv->get('default_text'),$resource->get('id'));
        if (strcmp($value,$default) != 0) {
            /* update the existing record */
            $tvc = $modx->getObject('modTemplateVarResource',array(
                'tmplvarid' => $tv->get('id'),
                'contentid' => $resource->get('id'),
            ));
            if ($tvc == null) {
                /* add a new record */
                $tvc = $modx->newObject('modTemplateVarResource');
                $tvc->set('tmplvarid',$tv->get('id'));
                $tvc->set('contentid',$resource->get('id'));
            }
            $tvc->set('value',$value);
            $tvc->save();

        /* if equal to default value, erase TVR record */
        } else {
            $tvc = $modx->getObject('modTemplateVarResource',array(
                'tmplvarid' => $tv->get('id'),
                'contentid' => $resource->get('id'),
            ));
            if ($tvc != null) $tvc->remove();
        }
        
        unset($_DATA['tv'.$tv_id]);
    }
}


/* save resource */
$resource->fromArray($_DATA);
if ($resource->save() === false) {
    $resource->removeLock();
    return $modx->error->failure($modx->lexicon('resource_err_save'));
}

$resource->removeLock();

/* empty cache */
$modx->cacheManager->refresh(array(
    'db' => array(),
    'auto_publish' => array('contexts' => array($resource->get('context_key'))),
    'context_settings' => array('contexts' => array($resource->get('context_key'))),
    'resource' => array('contexts' => array($resource->get('context_key'))),
));

return $modx->error->success();
