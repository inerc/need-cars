<?php
/**
 * pdoPage English Lexicon Entries for pdoTools
 *
 * @package pdotools
 * @subpackage lexicon
 * @language en
 */
$_lang['pdopage_first'] = 'First';
$_lang['pdopage_last'] = 'Last';