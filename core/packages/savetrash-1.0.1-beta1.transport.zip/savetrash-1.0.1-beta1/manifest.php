<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '63cf6dd2efa105cf37154fb330a0a3c4',
      'native_key' => 'savetrash',
      'filename' => 'modNamespace/04f8cb256fa0e45f7bd8071c72ae53c8.vehicle',
      'namespace' => 'savetrash',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'a59bdecc6b944ccffd09930ead9b61b5',
      'native_key' => 6,
      'filename' => 'modPlugin/eb1e9e345b5dbfced139e195cbf5687d.vehicle',
      'namespace' => 'savetrash',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4df825b21dccfbccecfd892ded763b8b',
      'native_key' => 1,
      'filename' => 'modCategory/3d47d561b04c9e7f3d665cbad604a065.vehicle',
      'namespace' => 'savetrash',
    ),
  ),
);