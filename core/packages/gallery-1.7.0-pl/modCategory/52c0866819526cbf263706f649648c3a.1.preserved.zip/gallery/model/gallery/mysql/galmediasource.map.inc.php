<?php
/**
 * @package gallery
 */
$xpdo_meta_map['galMediaSource']= array (
  'package' => 'gallery',
);
